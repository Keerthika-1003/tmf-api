package com.springai.service;

import java.util.ArrayList;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springai.pojo.UserAddress;
import com.springai.repo.UserRepo;

@Service
public class UserService {

	@Autowired
	private UserRepo userRepo;
	
	
	public String getHealthCheck() {
		return "200 OK";
	}
	
		
	public ArrayList<UserAddress> getAddress() {
		ArrayList<UserAddress> list = (ArrayList<UserAddress>) userRepo.findAll();
		if (list.size() == 0) {
			throw new NoSuchElementException("No data found");
		}
		try {
			return list;
		} catch (NoSuchElementException e) {
		}
		return list;
	}
}
