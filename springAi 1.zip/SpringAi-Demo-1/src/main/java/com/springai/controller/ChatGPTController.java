package com.springai.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.springai.dto.ChatGPTRequest;
import com.springai.dto.ChatGPTResponse;
import com.springai.dto.ChatGPTResponse.Choice;
import com.springai.pojo.UserAddress;
import com.springai.repo.UserRepo;


@RestController
@RequestMapping("/bot")
public class ChatGPTController {

	@Value("${openai.model}")
	private String model;
	
	@Value("${openai.api.url}")
	private String apiURL;
	
	@Autowired
	private RestTemplate template;
	
	@Autowired
	private UserRepo userRepo;
	
	@GetMapping("/chat")
	public String chat(@RequestParam("prompt") String prompt) {
		ChatGPTRequest request = new ChatGPTRequest(model, prompt);
		ChatGPTResponse chatGPTResponse = template.postForObject(apiURL, request, ChatGPTResponse.class);
		return chatGPTResponse.getChoices().get(0).getMessage().getContent();
	}

//	@GetMapping("/verifyAddress")
//	public String verifyAddress(@RequestParam("address") String address) {
//		String addressPrompt = "Give me the other variations of this address: " + address;
//		ChatGPTRequest request = new ChatGPTRequest(model, addressPrompt);
//		System.out.println(addressPrompt);
//		ChatGPTResponse chatGPTResponse = template.postForObject(apiURL, request, ChatGPTResponse.class);
//		return chatGPTResponse.getChoices().get(0).getMessage().getContent();
//	}
	
	
	@GetMapping("/verifyAddress")
	public List<Choice> verifyAddress(@RequestParam("address") String address) {
	    String addressPrompt = "Give me the complete other variations of this address in capital letters which should have expansions of directions, streets, avenues and cities: " + address;
	    System.out.println(addressPrompt);

	    ChatGPTRequest request = new ChatGPTRequest(model, addressPrompt);
	    ChatGPTResponse chatGPTResponse = template.postForObject(apiURL, request, ChatGPTResponse.class);
//	    System.out.println(chatGPTResponse.getChoices());
	    return chatGPTResponse.getChoices();
	}

	@GetMapping("/checkInRepo")
	public String checkInRepo(@RequestParam("address") String address) {
	    List<String> gptAddressVariations = verifyAddress(address);
//	    System.out.println(verifyAddress(address));

	    // Assuming AddressRepository has a method findByAddress that returns an Address object
	    // with the given address if it exists in the repository
	    for (Choice gptAddress : gptAddressVariations) {
//	    	System.out.println(gptAddress);
	  
	        UserAddress foundAddress = userRepo.findByAddress(gptAddress.getMessage().getContent());
//	        System.out.println(foundAddress);
	        if (foundAddress != null) {
	            return "Address found in repository: " + foundAddress.getAddress();
	        }
	    }

	    return "Address not found in repository";
	}
	
//	@Value("${openai.model}")
//    private String model;
//    
//    @Value("${openai.api.url}")
//    private String apiURL;
//    
//    @Autowired
//    private RestTemplate template;
//
//    @Autowired
//    private UserRepo userRepo;
//
//    @GetMapping("/verifyAddress")
//    public List<Choice> verifyAddress(@RequestParam("address") String address) {
//        String addressPrompt = "Give me the complete other variations of this address in capital letters which should have expansions of directions, streets, avenues and cities: " + address;
//        System.out.println(addressPrompt);
//
//        ChatGPTRequest request = new ChatGPTRequest(model, addressPrompt);
//        ChatGPTResponse chatGPTResponse = template.postForObject(apiURL, request, ChatGPTResponse.class);
//        return chatGPTResponse.getChoices();
//    }
//
//    @GetMapping("/checkInRepo")
//    public String checkInRepo(@RequestParam("address") String address) {
//        List<Choice> gptAddressVariations = verifyAddress(address);
//
//        for (Choice gptAddress : gptAddressVariations) {
//            UserAddress foundAddress = userRepo.findByAddress(gptAddress.getMessage().getContent());
//            if (foundAddress != null) {
//                return "Address found in repository: " + foundAddress.getAddress();
//            }
//        }
//
//        return "Address not found in repository";
//    }

	
}

