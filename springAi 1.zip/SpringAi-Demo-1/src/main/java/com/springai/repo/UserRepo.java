package com.springai.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springai.dto.ChatGPTResponse.Choice;
import com.springai.pojo.UserAddress;

@Repository
public interface UserRepo extends JpaRepository<UserAddress, String> {

	
//	@Transactional
//	@Modifying
//	@Query(value = "select * from useraddress where address = :gptAddress",nativeQuery = true)
//	public static UserAddress findByAddress(Choice gptAddress) {
//		return null;
//	}

	UserAddress findByAddress(String address);

}
