package com.example.tmf666.Repo;

import com.example.tmf666.Entity.FinancialAccount;
import org.springframework.data.jpa.repository.JpaRepository;



public interface FinancialAccountRepository extends JpaRepository<FinancialAccount, Long>{


}