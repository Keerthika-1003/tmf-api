package com.example.tmf666.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class FinancialAccount {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;
    private int accountNo;
    private String description;
    public FinancialAccount(Long id, int accountNo, String description) {
        super();
        this.id = id;
        this.accountNo = accountNo;
        this.description = description;
    }
    public FinancialAccount() {
        super();
        // TODO Auto-generated constructor stub
    }




}
