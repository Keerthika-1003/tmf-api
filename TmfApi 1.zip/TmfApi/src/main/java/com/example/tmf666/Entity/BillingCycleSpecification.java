package com.example.tmf666.Entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Data
@Entity
public class BillingCycleSpecification {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;
    private String cycleSpecification;
    private String presentationMedia;
    private String format;
        private String name;
        private String description;
    private int chargeDateOffset;
    private int creditDateOffset;
    private String frequency;
    private int MailingDateoffset;
    private int paymentDueDateOffset;
        private int billingDateShift;
        private String billingPeriod;


}

