package com.example.tmf666.Entity;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "BillingMedia")
public class BillingPresentationMedia {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id

    private String id;
    @Column(name = "href") // Specify exact column definition
    private String href;
    @Column(name = "name")
    private String name;
    @Column(name = "description") // Specify exact column definition
    private String description;

    public BillingPresentationMedia(String id, String href, String name, String description) {
        super();
        this.id = id;
        this.href = href;
        this.name = name;
        this.description = description;
    }

    public BillingPresentationMedia() {
        super();
        // TODO Auto-generated constructor stub
    }

}