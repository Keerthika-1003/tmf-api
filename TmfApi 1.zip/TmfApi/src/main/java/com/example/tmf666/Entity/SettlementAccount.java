package com.example.tmf666.Entity;



import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Data
@Table(name = "settlementaccount")
public class SettlementAccount {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;
    private String accountName;
    private String accountNumber;
    private String bankName;
    private String branch;
    private String accountType;
    private String currency;

    public SettlementAccount() {
        super();
        // TODO Auto-generated constructor stub
    }



}
