package com.example.tmf666.Controller;

import com.example.tmf666.Entity.BillFormat;
import com.example.tmf666.Repo.BillFormatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/tmf-api/accountManagement/v4")
public class BillFormatController {

    @Autowired
    private BillFormatRepository billFormatRepository;

    // Create a new BillFormat
    @PostMapping("/billFormat/create")
    public ResponseEntity<BillFormat> createBillFormat(@RequestBody BillFormat billFormatCreate) {
        BillFormat billFormat = new BillFormat();
        billFormat.setName(billFormatCreate.getName());
        billFormat.setDescription(billFormatCreate.getDescription());
        billFormat.setCreationDate(LocalDateTime.now());
        BillFormat savedBillFormat = billFormatRepository.save(billFormat);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedBillFormat);
    }

    // Get all BillFormats with pagination
    @GetMapping("/billFormat/getAll")
    public ResponseEntity<List<BillFormat>> listBillFormat(
            @RequestParam(required = false) String fields,
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "10") int limit) {

        Pageable pageable = PageRequest.of(offset, limit);
        Page<BillFormat> page = billFormatRepository.findAll(pageable);

        return ResponseEntity.ok()
                .header("X-Result-Count", String.valueOf(page.getNumberOfElements()))
                .header("X-Total-Count", String.valueOf(page.getTotalElements()))
                .body(page.getContent());
    }

    // Get a single BillFormat by id
    @GetMapping("/billFormat/{id}")
    public ResponseEntity<BillFormat> getBillFormatById(@PathVariable Long id) {
        Optional<BillFormat> billFormat = billFormatRepository.findById(id);
        return billFormat.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Update a BillFormat
    @PatchMapping("/billFormat/{id}")
    public ResponseEntity<BillFormat> updateBillFormat(@PathVariable Long id, @RequestBody BillFormat billFormatUpdate) {
        return billFormatRepository.findById(id)
                .map(billFormat -> {
                    billFormat.setName(billFormatUpdate.getName());
                    billFormat.setDescription(billFormatUpdate.getDescription());


                    BillFormat savedBillFormat = billFormatRepository.save(billFormat);
                    return ResponseEntity.ok(savedBillFormat);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/billFormat/{id}")
    public ResponseEntity<Void> deleteBillFormat(@PathVariable Long id) {
        if (billFormatRepository.existsById(id)) {
            billFormatRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}