package com.example.tmf666.Controller;

import com.example.tmf666.Entity.SettlementAccount;
import com.example.tmf666.Repo.SettlementAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/tmf-api/accountManagement/v4")
@RestController
public class SettlementController {

    @Autowired
    private SettlementAccountRepository settlementAccountRepository;

    @GetMapping("/getSettlementAccount/getAll")
    public ResponseEntity<List<SettlementAccount>> listSettlementAccount(
            @RequestParam(required = false) String fields, @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "10") int limit) {
        Pageable pageable = PageRequest.of(offset, limit);
        Page<SettlementAccount> page = settlementAccountRepository.findAll(pageable);
        return ResponseEntity.ok().header("X-Result-Count", String.valueOf(page.getNumberOfElements()))
                .header("X-Total-Count", String.valueOf(page.getTotalElements())).body(page.getContent());
    }

    @PostMapping("/settlementAccount/create")
    public String createSettlementAccount(@RequestBody SettlementAccount settlementAccount) {
        settlementAccountRepository.save(settlementAccount);
        return "created";
    }

    @GetMapping("/settlementAccount/{id}")
    public SettlementAccount retrieveSettlementAccount(@PathVariable Long id) {
        return settlementAccountRepository.findById(id).get();
    }

    @DeleteMapping("/deleteSettlementAccount/{id}")
    public String deleteSettlementAccount(@PathVariable Long id) {
        settlementAccountRepository.deleteById(id);
        return "Deleted";
    }

    @PatchMapping ("/settlementAccount/{id}")
    public ResponseEntity<SettlementAccount> updateSettlementAccount(@PathVariable Long id,
                                                                     @RequestBody SettlementAccount updatedSettlementAccount) {
        return settlementAccountRepository.findById(id).map(settlementAccount -> {
            settlementAccount.setAccountNo(updatedSettlementAccount.getAccountNo());
            settlementAccount.setDescription(updatedSettlementAccount.getDescription());
//			settlementAccount.setLastModifiedDate(LocalDateTime.now());

            SettlementAccount savedSettlementAccount = settlementAccountRepository.save(settlementAccount);
//					.save(billingCycleSpecification);

            return ResponseEntity.ok(savedSettlementAccount);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

}