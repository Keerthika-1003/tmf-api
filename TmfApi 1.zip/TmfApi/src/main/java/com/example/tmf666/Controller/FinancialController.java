package com.example.tmf666.Controller;

import  java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.example.tmf666.Entity.FinancialAccount;
import com.example.tmf666.Repo.FinancialAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/tmf-api/accountManagement/v4")
public class FinancialController {

    @Autowired
    private FinancialAccountRepository financialAccountRepository;

    @GetMapping("/listfinancialAccount/{id}")
    public ResponseEntity<List<FinancialAccount>> listFinancialAccount(
            @RequestParam(required = false) String fields,
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "10") int limit) {
        Pageable pageable = PageRequest.of(offset, limit);
        Page<FinancialAccount> page = financialAccountRepository.findAll(pageable);
        return ResponseEntity.ok()
                .header("X-Result-Count", String.valueOf(page.getNumberOfElements()))
                .header("X-Total-Count", String.valueOf(page.getTotalElements()))
                .body(page.getContent());
    }
    @PostMapping("/financialAccount/createFinancialAccount")
    public String createFinancialAccount(@RequestBody FinancialAccount financialAccount) {
        financialAccountRepository.save(financialAccount);
        return "created";
    }
    @GetMapping("/financialAccount/{id}")
    public FinancialAccount retrieveFinancialAccount(@PathVariable Long id) {
        return financialAccountRepository.findById(id).get();
    }

    @PatchMapping("/financialAccount/{id}")
    public ResponseEntity<FinancialAccount> patchFinancialAccount(@PathVariable Long id, @RequestBody FinancialAccount financialAccount) {
        Optional<FinancialAccount> optionalFinancialAccount = financialAccountRepository.findById(id);
        if (optionalFinancialAccount.isPresent()) {
            FinancialAccount updatedfinancialAccount = optionalFinancialAccount.get();

            // Update fields if they are not null in the updatedBillingCycleSpecification
            if (financialAccount.getAccountNo() != 0) {
                updatedfinancialAccount.setAccountNo(financialAccount.getAccountNo());
            }
            if (financialAccount.getDescription() != null) {
                updatedfinancialAccount.setDescription(financialAccount.getDescription());
            }

            // Save and return the updated entity
            FinancialAccount savedFinancialAccount = financialAccountRepository.save(updatedfinancialAccount);
            return ResponseEntity.ok(savedFinancialAccount);
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    @DeleteMapping("/deleteFinancialAccount/{id}")
    public String deleteFinancialAccount(@PathVariable Long id) {
        financialAccountRepository.deleteById(id);
        return "Deleted";
    }

}
