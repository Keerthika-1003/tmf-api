package com.example.tmf666.Controller;

import com.example.tmf666.Entity.PartyAccount;
import com.example.tmf666.Repo.PartyAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/tmf-api/accountManagement/v4")
public class PartyAccountController {

    @Autowired
    private PartyAccountRepository partyAccountRepository;

    // Create a new PartyAccount
    @PostMapping("/partyAccount/create")
    public ResponseEntity<PartyAccount> createPartyAccount(@RequestBody PartyAccount partyAccountCreate) {
        PartyAccount partyAccount = new PartyAccount();
        partyAccount.setName(partyAccountCreate.getName());
        partyAccount.setDescription(partyAccountCreate.getDescription());
        partyAccount.setStatus(partyAccountCreate.getStatus());
        partyAccount.setHref(partyAccount.getHref());
        partyAccount.setStatus(partyAccount.getStatus());
        partyAccount.setCreationDate(LocalDateTime.now());
        partyAccount.setLastModifiedDate(LocalDateTime.now());
        PartyAccount savedPartyAccount = partyAccountRepository.save(partyAccount);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedPartyAccount);
    }


    @GetMapping("/partyAccount/getAll")
    public ResponseEntity<List<PartyAccount>> listPartyAccount(
            @RequestParam(required = false) String fields,
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "10") int limit) {

        Pageable pageable = PageRequest.of(offset, limit);
        Page<PartyAccount> page = partyAccountRepository.findAll(pageable);

        return ResponseEntity.ok()
                .header("X-Result-Count", String.valueOf(page.getNumberOfElements()))
                .header("X-Total-Count", String.valueOf(page.getTotalElements()))
                .body(page.getContent());
    }

    // Get a single PartyAccount by id
    @GetMapping("/partyAccount/{id}")
    public ResponseEntity<PartyAccount> getPartyAccountById(@PathVariable Long id) {
        Optional<PartyAccount> partyAccount = partyAccountRepository.findById(id);
        return partyAccount.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Update a PartyAccount
    @PatchMapping("/partyAccount/{id}")
    public ResponseEntity<PartyAccount> updatePartyAccount(@PathVariable Long id, @RequestBody PartyAccount partyAccountUpdate) {
        return partyAccountRepository.findById(id)
                .map(partyAccount -> {
                    partyAccount.setName(partyAccountUpdate.getName());
                    partyAccount.setDescription(partyAccountUpdate.getDescription());
                    partyAccount.setStatus(partyAccountUpdate.getStatus());
                    partyAccount.setHref(partyAccountUpdate.getHref());
                    partyAccount.setStatus(partyAccountUpdate.getStatus());
                    partyAccount.setCreationDate(partyAccountUpdate.getCreationDate());
                    partyAccount.setLastModifiedDate(partyAccountUpdate.getLastModifiedDate());

                    PartyAccount savedPartyAccount = partyAccountRepository.save(partyAccount);
                    return ResponseEntity.ok(savedPartyAccount);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Delete a PartyAccount
    @DeleteMapping("/partyAccount/{id}")
    public ResponseEntity<Void> deletePartyAccount(@PathVariable Long id) {
        if (partyAccountRepository.existsById(id)) {
            partyAccountRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
