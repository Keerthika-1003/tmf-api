package com.example.tmf666.Repo;

import com.example.tmf666.Entity.BillFormat;
import com.example.tmf666.Entity.BillingCycleSpecification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BillingCycleSpecificationRepository extends JpaRepository<BillingCycleSpecification,Long> {

}
