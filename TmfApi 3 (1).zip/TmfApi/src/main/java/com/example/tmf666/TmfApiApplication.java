package com.example.tmf666;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@SpringBootApplication
public class TmfApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TmfApiApplication.class, args);
	}

}
