package com.example.tmf666.Repo;

import com.example.tmf666.Entity.EventSubscription;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventSubscriptionRepository extends JpaRepository<EventSubscription,Long> {
}
