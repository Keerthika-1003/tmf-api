package com.example.tmf666.Entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Data
@Entity
@Table(name = "billStructure")
public class BillStructure {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "bill_structure_id")
    private Long bill_structure_id;

    private BillFormat format;

}
